//
//  Blurit_SDK.h
//  Blurit_SDK
//
//  Created by Bertrand VILLAIN on 21/07/2021.
//

#import <Foundation/Foundation.h>
#include "LicenseKeyStatus.h"
#include "LicenseWrapper.h"

//! Project version number for Blurit.
FOUNDATION_EXPORT double BluritVersionNumber;

//! Project version string for Blurit.
FOUNDATION_EXPORT const unsigned char BluritVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Blurit/PublicHeader.h>


